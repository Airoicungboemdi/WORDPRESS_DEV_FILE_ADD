<?php

namespace UxBuilder\Collections;

class PostMetaOptions extends Collection {

}
